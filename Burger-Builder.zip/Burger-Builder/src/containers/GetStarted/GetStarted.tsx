import React, { Component } from 'react'
import classes from './GetStarted.module.css'

export default class GetStarted extends Component<any> {
    render() {
        return (
            <div className={classes.wrapper}>
                <div className={classes.loginContainer}>
                    <div className={classes.formContainer}>
                        <h1>Login</h1>
                        <div className={classes.icons}>
                            <i className="fa-brands fa-square-facebook"></i>

                            <i className="fa-brands fa-square-twitter"></i>
                        </div>
                        <form action="">
                            <label >or use your account</label>
                            <input type="text" placeholder="Name" value={this.props.name} onChange={this.props.nameChange}/>
                            <input type="text" placeholder="Address" value={this.props.address} onChange={this.props.addressChange}/>
                            {/* <label><a href="">Forgot your password?</a></label> */}
                            <button onClick={this.props.clickChange}>Get Started</button>
                        </form>
                    </div>
                    <div className={classes.descriptionContainer}>
                        <h1>
                            <span className={classes.formDescriptionMain}>HTML CSS Login Form</span>
                            <span className={classes.formDescriptionSub}
                            >This login form is created using pure HTML and CSS for social
                                icons. FontAwesome is used.</span>
                        </h1>
                    </div>
                </div>
            </div>
        )
    }
}
