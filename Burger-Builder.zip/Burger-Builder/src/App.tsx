import React, { useState } from "react";
import { BurgerBuilder } from "./containers/BurgerBuilder/BurgerBuilder";
import Layout from "./hoc/Layout/Layout";
import GetStarted from "./containers/GetStarted/GetStarted";

function App() {
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [clicked, setClicked] = useState(false)

  const handleNameChange = (event: any) => {
    setName(event.target.value);
  };

  const handleAddressChange = (event: any) => {
    setAddress(event.target.value);
  };

  const handleClickChange = () => {
    setClicked(!clicked);
  };

  return (
    <div>
      {clicked === false ? <GetStarted name={name} nameChange={handleNameChange} address={address} addressChange={handleAddressChange} clickChange={handleClickChange}/> : <Layout>
        <BurgerBuilder />
      </Layout>}

    </div>
  );
}
export default App;
