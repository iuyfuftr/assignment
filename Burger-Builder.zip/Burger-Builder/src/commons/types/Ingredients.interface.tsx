interface IIngredients{
  meat: number;
  cheese: number;
  salad: number;
  bacon: number;
}

export type {IIngredients};
